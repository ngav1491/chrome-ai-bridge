@echo off
setlocal
cd /d "%~dp0"

set "EXTENSION_ID=%~1"
set "EXTENSION_ID_ARGS="
if not "%EXTENSION_ID%"=="" set "EXTENSION_ID_ARGS=--extension-id %EXTENSION_ID%"

echo [chrome-ai-bridge] Installing runtime dependencies...

set "NODE_EXE=%ProgramFiles%\nodejs\node.exe"
set "NPM_CMD=%ProgramFiles%\nodejs\npm.cmd"

if exist "%NPM_CMD%" goto install
for %%I in (npm.cmd) do set "NPM_CMD=%%~$PATH:I"
if defined NPM_CMD goto install

echo [chrome-ai-bridge] ERROR: npm.cmd not found.
echo Install Node.js LTS from https://nodejs.org/, then reopen PowerShell and run install.bat again.
exit /b 1

:install
echo [chrome-ai-bridge] Using npm: %NPM_CMD%
call "%NPM_CMD%" install --omit=dev
if errorlevel 1 exit /b %errorlevel%

echo [chrome-ai-bridge] Resetting MCP stdio port to 12306...
if exist "distcli.js" (
  node distcli.js update-port 12306
  if errorlevel 1 exit /b %errorlevel%
  if "%EXTENSION_ID%"=="" (
    echo [chrome-ai-bridge] No extension ID argument supplied. If using an unpacked extension, rerun: install.bat YOUR_EXTENSION_ID
  )
  node distcli.js doctor --fix %EXTENSION_ID_ARGS%
  exit /b %errorlevel%
)

echo [chrome-ai-bridge] ERROR: dist\cli.js not found. Are you running install.bat from the extracted ZIP root?
exit /b 1
