# Chrome AI Bridge — Native Server (Windows)

Phần native messaging host cho Chrome extension chrome-ai-bridge.
Server lắng nghe trên port 12306, bind 0.0.0.0 (LAN accessible).

## Yêu cầu

- **Node.js 20+**: tải từ https://nodejs.org/ (chọn LTS)
- **Google Chrome** hoặc Chromium
- Windows 10/11

## Cài đặt

1. Giải nén ZIP này vào vị trí cố định, ví dụ `C:\chrome-ai-bridge\`
2. Mở PowerShell tại thư mục vừa giải nén
3. Load Chrome extension trước, mở `chrome://extensions`, bật Developer mode, copy dòng **ID** của extension chrome-ai-bridge.
4. Cài dependencies runtime và đăng ký native host với đúng extension ID:

   ```powershell
   .\install.bat jldpoegmnhhdnfahaombbppmpnjfdkki
   ```

   Nếu muốn chạy thủ công thay cho script:

   ```powershell
   npm.cmd install --omit=dev
   node dist\cli.js update-port 12306
   node dist\cli.js doctor --fix --extension-id jldpoegmnhhdnfahaombbppmpnjfdkki
   ```

4. Kiểm tra cài đặt:

   ```powershell
   node dist\cli.js doctor --extension-id jldpoegmnhhdnfahaombbppmpnjfdkki
   ```

5. Đăng ký Native Messaging host:

   ```powershell
   # Cấp người dùng (khuyến nghị, không cần admin)
   node dist\cli.js register --extension-id jldpoegmnhhdnfahaombbppmpnjfdkki

   # Hoặc cấp hệ thống (cần admin)
   node dist\cli.js register --system --extension-id jldpoegmnhhdnfahaombbppmpnjfdkki
   ```

## Đổi port hoặc host

Đặt biến môi trường trước khi chạy:

```powershell
# Đổi port
$env:CHROME_MCP_PORT=13000; node dist\cli.js register

# Giới hạn chỉ loopback (mặc định là 0.0.0.0 cho LAN)
$env:SERVER_HOST=127.0.0.1; node dist\cli.js register
```

## Cấu hình MCP client

Thêm vào file cấu hình MCP client (Claude Desktop, Cursor, Cherry Studio, ...):

```json
{
  "mcpServers": {
    "chrome-ai-bridge": {
      "type": "streamableHttp",
      "url": "http://127.0.0.1:12306/mcp"
    }
  }
}
```

Nếu MCP client chạy trên máy khác trong LAN, thay `127.0.0.1` bằng IP máy chủ.

## Gỡ cài đặt

```powershell
node dist\cli.js unregister
```

Hoặc xóa thủ công:
- File manifest: `%APPDATA%\Google\Chrome\NativeMessagingHosts\com.ngav1491.chrome_ai_bridge.nativehost.json`
- Registry key: `HKCU\Software\Google\Chrome\NativeMessagingHosts\com.ngav1491.chrome_ai_bridge.nativehost`

## Khắc phục sự cố

- **Cannot find module 'fastify', 'commander' hoặc dependency khác**: chạy `.\install.bat` tại thư mục gốc vừa giải nén
- **Node.js not found**: chạy `node dist\cli.js doctor --fix` hoặc set `$env:CHROME_MCP_NODE_PATH` trỏ tới `node.exe`
- **Port bị chiếm**: đổi port qua `$env:CHROME_MCP_PORT`
- **Extension ID mismatch**: mở `chrome://extensions`, copy dòng ID rồi chạy `node dist\cli.js register --extension-id ID_CUA_EXTENSION` hoặc `node dist\cli.js doctor --fix --extension-id ID_CUA_EXTENSION`
